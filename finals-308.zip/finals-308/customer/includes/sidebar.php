<div id="sidebar"><a href="#" class="visible-phone"> Dashboard</a>
  <ul>
    <li class="<?php if($page=='dashboard'){ echo 'active'; }?>"><a href="index.php"> <span>Dashboard</span></a> </li>
    <li class="<?php if($page=='todo'){ echo 'active'; }?>"> <a href="to-do.php"><span>To-Do</span></a>

    </li>

    <li class="<?php if($page=='reminder'){ echo 'active'; }?>"><a href="customer-reminder.php"> <span>Reminders</span></a></li>

    <li class="<?php if($page=='announcement'){ echo 'active'; }?>"><a href="announcement.php"><span>Announcement</span></a></li>

    <li class="<?php if($page=='report'){ echo 'active'; }?>"><a href="my-report.php"><span>Reports</span></a></li>
  </ul>
</div>