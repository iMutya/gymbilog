<?php

$servername="localhost";
$uname="root";
$pass="";
$db="gymnsb";

$conn=mysqli_connect($servername,$uname,$pass,$db);

if(!$conn){
    die("Connection Failed");
}
// tsakto ni very good pearl ann
$sql = "SELECT SUM( curr_weight - ini_weight) FROM members WHERE user_id='$id'";
        $amountsum = mysqli_query($conn, $sql) or die(mysqli_error($conn));
        $row_amountsum = mysqli_fetch_assoc($amountsum);
        $totalRows_amountsum = mysqli_num_rows($amountsum);
        echo $row_amountsum['SUM( curr_weight - ini_weight)'];

                
?>